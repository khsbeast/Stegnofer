import React from 'react'
import Navbar from '../../Components/Navbar/Navbar'
import Heading from '../../Components/Heading/Heading'
import {useState} from 'react'
import { useForm } from 'react-hook-form'
import CryptoJS from 'crypto-js';
import FileDownload from 'js-file-download'
import aes from 'crypto-js/aes';
import fs, { readFileSync } from "fs"
import './Hide.css'
import ScriptTag from 'react-script-tag'

export default function Hide() {
    
    const { register, handleSubmit } = useForm()
    const [iptext,setip] = useState(" ")
    const onSubmit = (data) => {
        console.log(data.image[0])
        const filePath = readFileSync(data.image[0])
        console.log(filePath)
    }
    const handleChange = (e) => {
        setip(e.target.value)
    }
    return (
        <>
        <Navbar/>
        <div id="box1">
        <Heading head="HIDE MESSAGE IN IMAGE" />
        <form onSubmit={handleSubmit(onSubmit)}>
                <input {...register('image', { required: true })} type="file" id="inp" />
                <p id="sk">ENTER HIDDEN TEXT</p>
                <div>
                <input id="ok" type="text" onChange={handleChange}/>
                </div>
                <div id="bt">
                <button className="button"><span>Hide</span></button>
                </div>
        </form>
        </div>
        </>
    )
}
