import React from 'react'
import './Heading.css'

const Heading = (props) => {
    return(
        <p id="head">{props.head}</p>
    )
}

export default Heading
